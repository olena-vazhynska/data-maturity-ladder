# Deployment Guide: Get a Shareable Link in 5 Minutes

This guide will help you deploy the Data Maturity Ladder tool to the web with a live, shareable link.

## 🚀 FASTEST METHOD: Vercel + GitHub (Recommended)

**Time: ~5 minutes | Cost: Free | Result: Live shareable link with auto-updates**

### Step 1: Create a GitHub Repository

1. **Go to [github.com](https://github.com)** and sign in (or create a free account)

2. **Click** "+" icon → **"New repository"**

3. **Fill in:**
   - Repository name: `data-maturity-ladder`
   - Description: `Data Maturity Ladder Self-Assessment Tool`
   - Choose: **Public** (so it's shareable)
   - Check: "Add a README file"

4. **Click "Create repository"**

### Step 2: Upload Your Files to GitHub

1. **Click "Add file"** → **"Upload files"**

2. **Drag and drop these folders/files into the browser:**
   ```
   public/
   src/
   package.json
   tailwind.config.js
   postcss.config.js
   vercel.json
   .gitignore
   README.md
   ```

3. **Scroll down** → **Click "Commit changes"**

### Step 3: Deploy to Vercel (1-Click!)

1. **Go to [vercel.com](https://vercel.com)**

2. **Sign up** (click "Continue with GitHub" - easiest)

3. **Authorize Vercel** to access your GitHub account

4. **Click "New Project"**

5. **Select your `data-maturity-ladder` repository**

6. **Click "Import"**

7. **Click "Deploy"** (no changes needed, defaults are perfect)

8. **⏳ Wait ~2 minutes** for build to complete

9. **🎉 GET YOUR LIVE LINK!**
   - Something like: `https://data-maturity-ladder.vercel.app`

### Step 4: Share Your Link!

Copy the URL and share:
```
https://data-maturity-ladder.vercel.app
```

✨ **Every time you update code on GitHub, Vercel auto-deploys in 1 minute!**

---

## Alternative Method: Netlify Deployment

If you prefer Netlify instead of Vercel:

1. **Go to [netlify.com](https://netlify.com)**

2. **Sign up** (click "Sign up with GitHub")

3. **Authorize Netlify** to access your GitHub

4. **Click "Add new site"** → **"Import an existing project"**

5. **Select GitHub** → **Find your repository**

6. **Click "Deploy site"**

7. **⏳ Wait for deployment**

8. **Get your Netlify URL** (something like `https://xxx-yyy-zzz.netlify.app`)

---

## Method 3: Vercel CLI (Direct Deployment)

For experienced developers, you can deploy directly without GitHub:

```bash
# Install Vercel CLI globally
npm install -g vercel

# In your project directory
cd data-maturity-ladder

# Deploy (follow prompts)
vercel

# Get live URL immediately!
```

---

## Troubleshooting

### Build Failed?

**Check these:**
1. Make sure all files are in the repository
2. `package.json` has correct dependencies
3. Node version compatibility (Vercel uses Node 18 by default)

**Fix:**
```bash
npm install
npm run build
```

### Link Not Working?

1. Wait 2-3 minutes for Vercel/Netlify build to complete
2. Check the deployment logs in Vercel dashboard
3. Make sure `public/index.html` exists

### Want to Update the Tool?

1. Make changes locally or in GitHub
2. Commit and push to GitHub
3. Vercel auto-deploys in ~1 minute
4. Refresh your link!

---

## Your New Shareable Link! 🎉

Once deployed, your link format will be:
```
https://data-maturity-ladder.vercel.app
```

**Share this link with participants!**

They can:
- ✅ Select their name from the list
- ✅ Complete the 6-question assessment
- ✅ Get personalized results
- ✅ Export their level and next steps

---

## Custom Domain (Optional)

Want a custom domain like `maturity.itcilo.org`?

**In Vercel:**
1. Go to your project settings
2. Click "Domains"
3. Add your custom domain
4. Follow DNS setup instructions

**In Netlify:**
1. Go to Domain settings
2. Add custom domain
3. Update DNS records with your provider

---

## Monitoring & Analytics

**Vercel Dashboard:**
- See who's accessing your tool
- Track deployment history
- View error logs
- Monitor performance

**To access:**
- Go to [vercel.com/dashboard](https://vercel.com/dashboard)
- Click your `data-maturity-ladder` project
- Explore Analytics tab

---

## FAQ

**Q: Is it really free?**
A: Yes! Vercel and Netlify free tiers are generous. You get unlimited deployments, bandwidth for reasonable traffic.

**Q: How many people can use it?**
A: Thousands! Free tier easily handles 1000s of concurrent users.

**Q: Can I modify participant names?**
A: Yes! Edit `src/components/DataMaturityLadder.jsx`, commit to GitHub, Vercel auto-updates.

**Q: How do I track results?**
A: Currently stored in browser memory. To save results, see "Advanced" section.

**Q: Can I use my own domain?**
A: Yes! Both Vercel and Netlify support custom domains.

---

## Next Steps (Advanced)

**Want to add result tracking/saving?**

1. Add a backend database (Firebase, Supabase)
2. Modify component to POST results
3. Display results history

**Want to add login system?**

1. Use Auth0 or Firebase Authentication
2. Restrict access to course participants only
3. Track individual results

**Want custom branding?**

1. Change colors in `tailwind.config.js`
2. Update logo/favicon
3. Modify course code/title in component

---

## Support

- **GitHub Issues:** Create issue in your repository
- **Vercel Help:** [vercel.com/help](https://vercel.com/help)
- **Netlify Help:** [netlify.com/support](https://netlify.com/support)

---

**Ready? Start with Step 1 above! You'll have a live link in 5 minutes.** ✨

Questions? Check the README.md in the main directory.

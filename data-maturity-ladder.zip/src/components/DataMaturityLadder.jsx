import React, { useState } from 'react';
import { ChevronRight, Check, AlertCircle, ArrowRight, Users } from 'lucide-react';

const DataMaturityLadder = () => {
  const participants = [
    { name: 'Matheus Alves Klein Viana', country: 'Brazil', role: 'General Coordinator for Labor Inspection' },
    { name: 'Mlungisi Mdumseni Mabuza', country: 'Eswatini', role: 'Labour Inspector' },
    { name: 'Sinya Godwell Mtawali', country: 'Malawi', role: 'Principal Industrial Hygienist' },
    { name: 'Nonyelum Calista Anayo-Uzochukwu', country: 'Nigeria', role: 'Assistant Chief Maritime Labour Officer' },
    { name: 'Yusuf Halilu', country: 'Nigeria', role: 'Assistant Director Shipping Development' },
    { name: 'Muhammad Duri Haruna', country: 'Nigeria', role: 'Assistant Chief Marine Engineer' },
    { name: 'Nkiru Theresa Nwana', country: 'Nigeria', role: 'Chief Maritime Labour Officer' },
    { name: 'Christopher Dio Okpanachi', country: 'Nigeria', role: 'Assistant Chief Executive Officer' },
    { name: 'Linda Ogadinma Okpara', country: 'Nigeria', role: 'Assistant Legal Adviser' },
    { name: 'Margaret Israel Udoh', country: 'Nigeria', role: 'Chief Accountant' },
    { name: 'Hamida Ali', country: 'Tunisia', role: 'Head of the Labour Control Unit' },
    { name: 'Mert Eksi', country: 'Türkiye', role: 'Labour Inspector' },
    { name: 'Vedat Üçtas', country: 'Türkiye', role: 'Labour Inspector' },
    { name: 'Vadym Bondar', country: 'Ukraine', role: 'Head of Market Surveillance' },
    { name: 'Ihor Dehnera', country: 'Ukraine', role: 'Head' },
    { name: 'Oleh Honchar', country: 'Ukraine', role: 'Head of Investigation & Analysis Division' },
    { name: 'Oleksandr Ihnatov', country: 'Ukraine', role: 'Director of Occupational Safety' },
    { name: 'Olena Konovalova', country: 'Ukraine', role: 'Deputy Director - Labour Legislation' },
    { name: 'Svitlana Nichyk', country: 'Ukraine', role: 'Deputy Director - Analytical Support' },
    { name: 'Ruslan Pavlovskyi', country: 'Ukraine', role: 'Deputy Chief Southern Department' },
    { name: 'Oleksandr Rozumnyi', country: 'Ukraine', role: 'Head of North-Eastern Administration' },
    { name: 'Roman Semchuk', country: 'Ukraine', role: 'Head' },
    { name: 'Sergii Baidiuk', country: 'Ukraine', role: 'Head of Southern Department' },
    { name: 'Andrii Tymenko', country: 'Ukraine', role: 'Deputy Head Central Department' },
    { name: 'Ada', country: 'ILO', role: 'International Labour Organization' },
    { name: 'Rumsha', country: 'ILO', role: 'International Labour Organization' },
    { name: 'Tetyana', country: 'ILO', role: 'International Labour Organization' },
    { name: 'ITCILO', country: 'Testing', role: 'For Testing Purposes' },
    { name: 'Guest', country: 'Guest', role: 'Course Participant' },
  ];

  const maturityLevels = [
    {
      level: 1,
      title: 'Analog',
      emoji: '📄',
      description: 'Paper records and personal spreadsheets',
      characteristics: [
        'Records are on paper or in personal spreadsheets',
        'No centralized system',
        'Manual red-flagging by experience',
        'Limited data sharing'
      ],
      nextStep: 'Digitize your core datasets'
    },
    {
      level: 2,
      title: 'Digitized',
      emoji: '💾',
      description: 'E-system exists but is siloed',
      characteristics: [
        'Case-management system in place',
        'Data is stored digitally',
        'Used only for retrieval and storage',
        'Limited integration with other data'
      ],
      nextStep: 'Link to at least one external register (tax, social-security, business)'
    },
    {
      level: 3,
      title: 'Integrated',
      emoji: '🔗',
      description: 'Linked to ≥1 external register',
      characteristics: [
        'Inspection data linked to external registry',
        'Descriptive dashboards available',
        'Cross-system data flows established',
        'Regular reporting possible'
      ],
      nextStep: 'Implement routine trend analysis and manual scoring'
    },
    {
      level: 4,
      title: 'Analytical',
      emoji: '📊',
      description: 'Trend analysis & manual red-flag scoring',
      characteristics: [
        'Routine trend analysis conducted',
        'Manual risk-scoring for targeting',
        'Data quality controls in place',
        'Performance KPIs tracked'
      ],
      nextStep: 'Deploy machine learning models with explainable outputs'
    },
    {
      level: 5,
      title: 'Predictive / AI',
      emoji: '🤖',
      description: 'ML models with explainable outputs',
      characteristics: [
        'Machine learning models drive targeting',
        'Explainable, white-box decision logic',
        'Continuous model retraining',
        'AI-guided inspection allocation'
      ],
      nextStep: 'Expand to multi-risk models and cross-border cooperation'
    }
  ];

  const assessmentQuestions = [
    {
      id: 1,
      category: 'Data Storage',
      question: 'How are your inspection records currently stored?',
      answers: [
        { text: 'Paper files or personal spreadsheets', score: 1 },
        { text: 'Digital case-management system (siloed)', score: 2 },
        { text: 'Digital system with some external linkages', score: 3 },
        { text: 'Integrated digital system with dashboards', score: 4 },
        { text: 'Advanced system with analytics and dashboards', score: 5 }
      ]
    },
    {
      id: 2,
      category: 'Data Integration',
      question: 'Are your inspection data linked to external registers?',
      answers: [
        { text: 'No external linkages', score: 1 },
        { text: 'Planned but not yet implemented', score: 2 },
        { text: 'Linked to one external source', score: 3 },
        { text: 'Linked to multiple external sources', score: 4 },
        { text: 'Full integration with real-time external data', score: 5 }
      ]
    },
    {
      id: 3,
      category: 'Targeting & Risk Signals',
      question: 'How do you identify which workplaces to inspect?',
      answers: [
        { text: 'Mostly from experience and complaints', score: 1 },
        { text: 'Historical patterns plus reactive complaints', score: 2 },
        { text: 'Data-driven targeting based on simple rules', score: 3 },
        { text: 'Manual scoring system with defined risk signals', score: 4 },
        { text: 'Predictive models with AI-driven prioritization', score: 5 }
      ]
    },
    {
      id: 4,
      category: 'Data Quality & Governance',
      question: 'What is the quality of your data?',
      answers: [
        { text: 'Inconsistent, many gaps, not timely', score: 1 },
        { text: 'Mostly complete, occasional errors, delayed', score: 2 },
        { text: 'Generally complete, some quality issues', score: 3 },
        { text: 'High quality with formal controls and standards', score: 4 },
        { text: 'Excellent with automated validation and monitoring', score: 5 }
      ]
    },
    {
      id: 5,
      category: 'Analytics & Reporting',
      question: 'Can you produce KPIs and trend reports?',
      answers: [
        { text: 'Limited reporting, mostly manual', score: 1 },
        { text: 'Annual reports produced manually', score: 2 },
        { text: 'Regular reports with basic dashboards', score: 3 },
        { text: 'Routine trend analysis and KPI dashboards', score: 4 },
        { text: 'Real-time dashboards with predictive analytics', score: 5 }
      ]
    },
    {
      id: 6,
      category: 'Technology & Capacity',
      question: 'What is your organization\'s technical capacity?',
      answers: [
        { text: 'Minimal IT infrastructure', score: 1 },
        { text: 'Basic systems, limited analytics skills', score: 2 },
        { text: 'Functional systems, some analytical capability', score: 3 },
        { text: 'Strong systems and analytical staff', score: 4 },
        { text: 'Advanced systems with data science expertise', score: 5 }
      ]
    }
  ];

  const [stage, setStage] = useState('nameSelection');
  const [selectedParticipant, setSelectedParticipant] = useState(null);
  const [answers, setAnswers] = useState({});
  const [filterCountry, setFilterCountry] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const countries = [...new Set(participants.map(p => p.country))].sort();

  const filteredParticipants = participants.filter(p => {
    const matchCountry = !filterCountry || p.country === filterCountry;
    const matchSearch = !searchTerm || p.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCountry && matchSearch;
  });

  const calculateResults = () => {
    const scores = Object.values(answers).map(a => parseInt(a));
    const average = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b) / scores.length) : 0;
    const categoryScores = {};
    
    assessmentQuestions.forEach(q => {
      if (!categoryScores[q.category]) categoryScores[q.category] = [];
      categoryScores[q.category].push(parseInt(answers[q.id]) || 0);
    });

    const categoryAverages = {};
    Object.keys(categoryScores).forEach(cat => {
      categoryAverages[cat] = Math.round(
        categoryScores[cat].reduce((a, b) => a + b) / categoryScores[cat].length
      );
    });

    return { average, categoryAverages };
  };

  const handleAnswerSelect = (questionId, score) => {
    setAnswers(prev => ({...prev, [questionId]: score}));
  };

  const handleStartAssessment = (participant) => {
    setSelectedParticipant(participant);
    setAnswers({});
    setStage('questions');
  };

  const handleCompleteAssessment = () => {
    setStage('results');
  };

  const handleRestart = () => {
    setSelectedParticipant(null);
    setAnswers({});
    setStage('nameSelection');
  };

  const results = stage === 'results' ? calculateResults() : null;
  const maturityLevel = results ? maturityLevels[results.average - 1] || maturityLevels[0] : null;
  const answeredCount = Object.keys(answers).length;
  const progressPercent = (answeredCount / assessmentQuestions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-block mb-4 px-4 py-2 bg-blue-500/20 rounded-full border border-blue-400/50">
            <span className="text-xs font-bold tracking-widest text-blue-300 uppercase">A9718841 Session 3</span>
          </div>
          <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-3">
            Data Maturity Ladder
          </h1>
          <p className="text-lg text-slate-300">
            Self-Assessment for Labour Inspectorates
          </p>
        </div>

        {/* STAGE 1: Name Selection */}
        {stage === 'nameSelection' && (
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl p-8 border border-slate-700">
            <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
              <Users size={32} className="text-blue-400" />
              Select Your Name
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <input
                type="text"
                placeholder="🔍 Search by name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30"
              />
              
              <select
                value={filterCountry}
                onChange={(e) => setFilterCountry(e.target.value)}
                className="px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="">All Countries ({participants.length})</option>
                {countries.map(country => {
                  const count = participants.filter(p => p.country === country).length;
                  return (
                    <option key={country} value={country}>
                      {country} ({count})
                    </option>
                  );
                })}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
              {filteredParticipants.map((participant, idx) => (
                <button
                  key={idx}
                  onClick={() => handleStartAssessment(participant)}
                  className="text-left p-4 bg-gradient-to-br from-slate-700 to-slate-800 border-2 border-slate-600 rounded-lg hover:border-blue-400 hover:from-blue-900/40 hover:to-slate-800 transition-all hover:shadow-lg hover:shadow-blue-500/20"
                >
                  <div className="font-bold text-white text-sm">{participant.name}</div>
                  <div className="text-xs text-blue-400 font-semibold mt-2">{participant.country}</div>
                  <div className="text-xs text-slate-400 mt-2">{participant.role}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STAGE 2: Assessment Questions */}
        {stage === 'questions' && selectedParticipant && (
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl p-8 border border-slate-700">
            <div className="mb-8 p-6 bg-gradient-to-r from-blue-900/40 to-purple-900/40 rounded-lg border border-blue-500/30">
              <h3 className="font-bold text-white text-lg">{selectedParticipant.name}</h3>
              <p className="text-slate-300 mt-1 text-sm">{selectedParticipant.country}</p>
            </div>

            <div className="mb-8">
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-semibold text-slate-300">Progress</h4>
                <span className="text-sm font-bold text-blue-400">{answeredCount}/{assessmentQuestions.length}</span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            <h2 className="text-3xl font-bold text-white mb-8">Data Maturity Assessment</h2>

            <div className="space-y-8">
              {assessmentQuestions.map((question) => (
                <div key={question.id} className="border-l-4 border-blue-500 pl-6 pb-6 border-b border-slate-700 last:border-b-0">
                  <div className="mb-4">
                    <h4 className="text-lg font-bold text-white">{question.question}</h4>
                    <p className="text-sm text-slate-400 mt-1">📁 {question.category}</p>
                  </div>

                  <div className="space-y-2">
                    {question.answers.map((answer, idx) => (
                      <label
                        key={idx}
                        className={`flex items-start p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          answers[question.id] === String(answer.score)
                            ? 'bg-blue-900/40 border-blue-400 shadow-lg shadow-blue-500/20'
                            : 'border-slate-600 hover:bg-slate-700/50'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`question-${question.id}`}
                          value={answer.score}
                          checked={answers[question.id] === String(answer.score)}
                          onChange={() => handleAnswerSelect(question.id, answer.score)}
                          className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5 cursor-pointer"
                        />
                        <span className="ml-4 flex-1 text-slate-200 text-sm">{answer.text}</span>
                        <span className="ml-2 text-xs font-bold text-slate-400">Lv{answer.score}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4 mt-10">
              <button
                onClick={handleRestart}
                className="px-6 py-3 border-2 border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 font-semibold transition-colors"
              >
                ← Back
              </button>
              <button
                onClick={handleCompleteAssessment}
                disabled={answeredCount < assessmentQuestions.length}
                className={`flex-1 px-6 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all ${
                  answeredCount < assessmentQuestions.length
                    ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-lg hover:shadow-blue-500/30'
                }`}
              >
                View Results <ChevronRight size={20} />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 3: Results */}
        {stage === 'results' && selectedParticipant && results && maturityLevel && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl p-12 border border-slate-700 text-center">
              <p className="text-slate-400 font-semibold mb-4 uppercase tracking-widest">Your Data Maturity Level</p>
              <div className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-4">
                {results.average}
              </div>
              <h2 className="text-5xl font-bold text-white mb-3 flex items-center justify-center gap-3">
                {maturityLevel.emoji} {maturityLevel.title}
              </h2>
              <p className="text-xl text-slate-300">{maturityLevel.description}</p>
            </div>

            <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl p-8 border border-slate-700">
              <h3 className="text-2xl font-bold text-white mb-8">Scores by Category</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(results.categoryAverages).map(([category, score]) => (
                  <div key={category}>
                    <div className="flex justify-between items-center mb-3">
                      <label className="font-bold text-white">{category}</label>
                      <span className="text-2xl font-black text-blue-400">{score}</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-4 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-4 rounded-full transition-all"
                        style={{ width: `${(score / 5) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl p-8 border border-slate-700">
              <h3 className="text-xl font-bold text-white mb-6">
                ✓ Your Current Level: {maturityLevel.title}
              </h3>
              <ul className="space-y-3">
                {maturityLevel.characteristics.map((char, idx) => (
                  <li key={idx} className="flex items-start gap-4">
                    <Check size={24} className="text-green-400 flex-shrink-0 mt-0" />
                    <span className="text-slate-200">{char}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gradient-to-br from-amber-900/30 to-orange-900/30 rounded-2xl shadow-2xl p-8 border border-amber-700/50">
              <h4 className="text-xl font-bold text-amber-100 mb-4 flex items-center gap-3">
                <ArrowRight className="text-amber-400" size={24} />
                Your Next Step
              </h4>
              <p className="text-lg text-amber-50 font-semibold mb-6 p-4 bg-slate-900/50 rounded-lg border border-amber-700/50">
                {maturityLevel.nextStep}
              </p>
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleRestart}
                className="flex-1 px-6 py-4 border-2 border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 font-semibold transition-colors"
              >
                Start New
              </button>
              <button
                onClick={handleRestart}
                className="flex-1 px-6 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg font-semibold"
              >
                Assess Another
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataMaturityLadder;

# Data Maturity Ladder Self-Assessment Tool

🎯 **Interactive assessment tool for labour inspectorates** - Session 3 Diagnostic Exercise (A9718841)

![React](https://img.shields.io/badge/React-18.2-61DAFB?logo=react)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)

## Overview

An interactive self-assessment tool that guides labour inspectors through 6 diagnostic questions to measure their organization's data maturity on a 5-level ladder. Participants receive personalized feedback and actionable next steps based on their assessment results.

**Participants:** 32 labour inspectors from 7 countries + ILO staff (Brazil, Eswatini, Malawi, Nigeria, Tunisia, Türkiye, Ukraine)

## Features

✅ **Personalized Assessments**
- 32 pre-loaded course participants by name and country
- 4 ILO staff (Ada, Rumsha, Tetyana)
- Testing and Guest options

✅ **6-Question Guided Assessment**
- Data Storage
- Data Integration
- Targeting & Risk Signals
- Data Quality & Governance
- Analytics & Reporting
- Technology & Capacity

✅ **Comprehensive Results**
- Overall maturity level (1-5)
- Category-by-category breakdown
- Visual progress indicators
- Next steps and action items
- Interactive maturity ladder timeline

✅ **Beautiful UI**
- Dark gradient theme optimized for readability
- Mobile responsive design
- Smooth transitions and animations
- Accessible input controls

## Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/ITCILO/data-maturity-ladder.git
cd data-maturity-ladder
npm install
```

### 2. Run Locally

```bash
npm start
```

Opens [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for Production

```bash
npm run build
```

Creates an optimized production build in the `build/` folder.

## 🚀 Deploy to Vercel (FREE - 1 Click)

**Vercel gives you a free shareable link that auto-updates when you push to GitHub**

### Option A: With GitHub (Recommended)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/data-maturity-ladder.git
   git push -u origin main
   ```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign up (free, with GitHub)
   - Click "New Project"
   - Import your GitHub repository
   - Click "Deploy"
   - **Done!** Your live link: `https://data-maturity-ladder.vercel.app`

### Option B: Direct Vercel Deployment

1. **Install Vercel CLI**
   ```bash
   npm i -g vercel
   ```

2. **Deploy**
   ```bash
   vercel
   ```

3. **Follow prompts** → Get live link instantly

## 📋 Project Structure

```
data-maturity-ladder/
├── public/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── App.js
│   ├── index.js
│   ├── App.css
│   └── components/
│       └── DataMaturityLadder.jsx
├── package.json
├── README.md
├── .gitignore
├── vercel.json
└── tailwind.config.js
```

## 🛠️ Technology Stack

- **React 18.2** - UI library
- **Tailwind CSS** - Styling (dark mode optimized)
- **Lucide React** - Icons
- **React Scripts** - Build tools

## 📊 Data Structure

### Participants (32 total)
```javascript
{
  name: string,
  country: string,
  role: string
}
```

### Assessment Questions (6 total)
Each with 5-level Likert responses (1=Analog → 5=Predictive/AI)

### Results
- Overall average score
- Category-by-category breakdown
- Maturity level characteristics
- Next steps recommendations

## 🎨 Customization

### Add/Edit Participants

Edit `src/components/DataMaturityLadder.jsx` - `participants` array:

```javascript
const participants = [
  {
    name: 'Your Name',
    country: 'Your Country',
    role: 'Your Role'
  },
  // ... more
];
```

### Modify Questions

Edit `assessmentQuestions` array in the same file:

```javascript
const assessmentQuestions = [
  {
    id: 1,
    category: 'Your Category',
    question: 'Your question?',
    answers: [
      { text: 'Option 1', score: 1 },
      // ... 5 options total
    ]
  },
  // ... more
];
```

### Change Colors

Edit `tailwind.config.js` or use Tailwind utility classes directly in components.

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📄 License

MIT License - See LICENSE file for details

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/improvement`)
3. Commit your changes (`git commit -am 'Add improvement'`)
4. Push to the branch (`git push origin feature/improvement`)
5. Open a Pull Request

## 📧 Support

Questions or feedback? 
- Create an issue in GitHub
- Contact: [ITCILO](https://www.itcilo.org)

## 🎓 Course Information

- **Course Code:** A9718841
- **Course Title:** Agile Labour Inspection: Digital Transformations for Workplace Compliance
- **Session:** Session 3 - "Where are we? Data and Indicators"
- **Facilitator:** Olena
- **Date:** June 12-26, 2026

---

**Bring your assessment results and one burning question to the AI Clinic in Turin! 🚀**

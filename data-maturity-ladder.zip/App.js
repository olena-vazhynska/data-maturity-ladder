import React from 'react';
import DataMaturityLadder from './components/DataMaturityLadder';
import './App.css';

function App() {
  return (
    <div className="App">
      <DataMaturityLadder />
    </div>
  );
}

export default App;
